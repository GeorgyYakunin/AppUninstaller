package com.app.uninstaller.appuninstaller212;

import com.app.uninstaller.appuninstaller212.model.PInfo;

import java.util.List;

public interface ITotalSize {
    void total(int count, double total, List<PInfo> listDelete);
}
