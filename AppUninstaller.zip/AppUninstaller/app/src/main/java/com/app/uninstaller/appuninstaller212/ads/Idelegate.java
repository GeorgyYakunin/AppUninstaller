//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by Fernflower decompiler)
//

package com.app.uninstaller.appuninstaller212.ads;

public interface Idelegate {
    void callBack(Object value, int where);
}
